module.exports = dbconnnection = {
    connectionLimit: 15,
    host : 'us-cdbr-iron-east-01.cleardb.net' || process.env.DB_HOST,
    user : 'b745ac5c2fd726' || process.env.DB_USER,
    password :'14927d40' || process.env.DB_PASS,
    database : 'heroku_2b60bc193f6db4f' || process.env.DB_DATABASE
};

var express = require("express");
var pool = require("../DB/mysqldb");
var router = express.Router();

router.get("/", (req, res, next) => {
  let bookCode = req.query.bookCode;
  let branchNum = req.query.branchNum;
  let copyNum = req.query.copyNum;
  let quality = req.query.quality;
  let price = req.query.price;

  if (bookCode) {
    query = `SELECT * FROM copy WHERE copy.bookCode = '${bookCode}';`;
  } else if (branchNum) {
    query = `SELECT * FROM copy WHERE copy.branchNum = '${branchNum}';`;
  } else if (copyNum) {
    query = `SELECT * FROM copy WHERE copy.copyNum = '${copyNum}';`;
  } else if (quality) {
    query = `SELECT * FROM copy WHERE copy.quality = '${quality}';`;
  } else if (price) {
    query = `SELECT * FROM copy WHERE copy.price = '${price}';`;
  } else {
    query = `SELECT * FROM copy;`;
  }

  pool.query(query, (err, result) => {
    res.send(result);
  });
});

router.post("/", (req, res) => {
  let reqType = req.query.reqType || "";
  let bookCode = req.query.bookCode || "";
  let copyNum = req.query.copyNum || "";
  let quality = req.query.quality || "";
  let price = req.query.price || "";
  let branchNum = req.query.branchNum || "";

  switch (reqType) {
    case "add":
      pool.query(
        `SELECT MAX(copyNum) + 1 AS nextCopy FROM copy WHERE bookCode='${bookCode}' AND branchNum='${branchNum}'`,
        (err, nextCopy) => {
          let nc = nextCopy[0].nextCopy;

          pool.query(
            `INSERT INTO copy (bookCode,branchNum,copyNum,quality,price) VALUES ('${bookCode}','${branchNum}','${nextCopy[0].nextCopy}','${quality}','${price}');`,
            (err, result) => {
              pool.query(`INSERT INTO inventory (BookCode,BranchNum,OnHand) VALUES('${bookCode}','${branchNum}','${nextCopy[0].nextCopy}');`,
                (err, result) => {
                  res.send(result);
                }
              );
            }
          );
        }
      );
      break;
    case "delete":
      pool.query(
        `DELETE FROM copy WHERE bookCode='${bookCode}' AND branchNum=${branchNum} AND copyNum=${copyNum}`,
        (err, deleted) => {
          pool.query(
            `SELECT copyNum FROM copy WHERE bookCode='${bookCode}' AND branchNum=${branchNum}`,
            (err, copy) => {
              if(copy[0].copyNum.length < 1) {
                copy[0].copyNum.forEach((copyN, idx) => {
                  pool.query(
                    `UPDATE copy SET copyNum=${idx + 1} WHERE bookCode='${bookCode}' AND branchNum=${branchNum}`,
                    (err, result) => {
                      res.send(result);
                    }
                  );
                });

                pool.query(
                  `UPDATE inventory SET OnHand = (SELECT OnHand from inventory where BookCode = '${bookCode}') - 1 where BookCode = '${bookCode}' ;`,
                  (err, result) => {
                    res.send(result);
                  }
                );
              } else {
                res.send(copy)
              }

            }
          );
        }
      );
      
      
      break;
    case "update":
      pool.query(
        `UPDATE copy SET quality = '${quality}', price = ${price}, branchName = '${branchName}', branchLocation = '${branchLocation}' WHERE bookCode='${bookCode}' AND branchNum=${branchNum} AND copyNum=${copyNum}`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    default:
      pool.query(`SELECT * FROM copy`, (err, result) => {
        res.send(result);
      });
  }
});

module.exports = router;

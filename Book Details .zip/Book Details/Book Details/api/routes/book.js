var express = require("express");
var pool = require("../DB/mysqldb");
var router = express.Router();

router.get("/", (req, res, next) => {
  let bookCode = req.query.bookCode;
  let title = req.query.title;
  let publisherCode = req.query.publisherCode;
  let query;

  if (bookCode) {
    query = `SELECT book.bookCode, title, book.publisherCode, book.type, book.paperback, book.url FROM book WHERE book.bookCode = '${bookCode}';`;
  } else if (title) {
    query = `SELECT book.bookCode, title, book.publisherCode, book.type, book.paperback, book.url FROM book WHERE book.title = '${title}';`;
  } else if (publisherCode) {
    query = `SELECT distinct publisherCode from publisher;`;
  } else {
    query = `SELECT * FROM book;`;
  }

  pool.query(query, (err, result) => {
    res.send(result);
  });
});

router.post("/", (req, res) => {
  let reqType = req.query.reqType || "";
  let bookCode = req.query.bookCode || "";
  let title = req.query.title | "";
  let publisherCode = req.query.publisherCode | "";
  let type = req.query.type || "";
  let paperback = req.query.paperback | "";

  switch (reqType) {
    case "add":
      pool.query(
        `INSERT INTO book (bookCode,title,publisherCode,type,paperback) VALUES (${bookCode},'${title}','${publisherCode}','${type}','${paperback}');`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    case "delete":
      pool.query(
        `DELETE FROM book WHERE bookCode=${bookCode}`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    case "update":
      pool.query(
        `UPDATE book SET title = ${title}, publisherCode = ${publisherCode}, type = ${type}, paperback = ${paperback} WHERE bookCode = ${bookCode};`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    default:
      pool.query(`SELECT * FROM book`, (err, result) => {
        res.send(result);
      });
  }
});

module.exports = router;

var express = require("express");
var pool = require("../DB/mysqldb");
var router = express.Router();


router.get("/", (req, res, next) => {
    let bookCode = req.query.BookCode;
    let branchNum = req.query.BranchNum;
    let onHand = req.query.OnHand;
    let query;

    if(bookCode){
        query = `SELECT * Inventory WHERE Inventory.BookCode = '${bookCode}';`;
    } else if(branchNum){
        query = `SELECT * Inventory WHERE Inventory.BranchNum = '${branchNum}';`;
    } else if(onHand){
        query = `SELECT * Inventory WHERE Inventory.OnHand = '${onHand}';`;
    }
    else {
      query = `SELECT * FROM Inventory;`;
    }
    
    pool.query(query, (err, result) => {
      res.send(result);
    });
  });

module.exports = router;

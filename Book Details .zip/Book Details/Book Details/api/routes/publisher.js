var express = require("express");
var pool = require("../DB/mysqldb");
var router = express.Router();

router.get("/", (req, res, next) => {
  let publisherCode = req.query.publisherCode;
  let publisherName = req.query.publisherName;
  let city = req.query.city;


  if (publisherCode) {
    query = `SELECT * FROM Publisher WHERE Publisher.publisherCode = '${publisherCode}';`;
  } else if (publisherName) {
    query = `SELECT * FROM Publisher WHERE Publisher.publisherName = '${publisherName}';`;
  } else if (city) {
    query = `SELECT * FROM Publisher WHERE Publisher.city = '${city}';`;
  } else {
    query = `SELECT * FROM Publisher;`;
  }

  pool.query(query, (err, result) => {
    res.send(result);
  });
});

router.post("/", (req, res) => {
  let reqType = req.query.reqType || "";
  let publisherName = req.query.publisherName|| "";
  let city = req.query.city | "";
  let publisherCode = req.query.publisherCode | "";

  switch (reqType) {
    case "add":
      pool.query(
        `INSERT INTO publisher (publisherCode,publisherName,city) VALUES ('${publisherCode}','${publisherName}','${city}');`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    case "delete":
      pool.query(
        `DELETE FROM publisher WHERE publisherCode=${publisherCode}`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    case "update":
      pool.query(
        `UPDATE publisher SET publisherCode = '${publisherCode}', publisherName= '${publisherName}', city = '${city}' WHERE publisherCode = '${publisherCode}';`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    default:
      pool.query(`SELECT * FROM publisher`, (err, result) => {
        res.send(result);
      });
  }
});

module.exports = router;

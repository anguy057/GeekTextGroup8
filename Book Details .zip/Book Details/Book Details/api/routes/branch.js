var express = require("express");
var pool = require("../DB/mysqldb");
var router = express.Router();

router.get("/", (req, res, next) => {
  let branhcNum = req.query.branhcNum;
  let branchName = req.query.branchName;
  let branchLocation = req.query.branchLocation;

  if (branhcNum) {
    query = `SELECT * FROM branch WHERE branch.branchNum = '${branhcNum}';`;
  } else if (branchName) {
    query = `SELECT * FROM branch WHERE branch.branchName = '${branchName}';`;
  } else if (branchLocation) {
    query = `SELECT * FROM branch WHERE branch.branchLocation = '${branchLocation}';`;
  } else {
    query = `SELECT * FROM branch;`;
  }

  pool.query(query, (err, result) => {
    res.send(result);
  });
});

router.post("/", (req, res) => {
  let reqType = req.query.reqType || "";
  let branchNum = req.query.branchNum || "";
  let branchName = req.query.branchName | "";
  let branchLocation = req.query.branchLocation | "";

  switch (reqType) {
    case "add":
      pool.query(
        `SELECT COUNT(branchNum) + 1 AS nextBranchID FROM Branch`,
        (err, nextBranch) => {
          pool.query(
            `INSERT INTO branch (branchNum,branchName,branchLocation) VALUES (${nextBranch[0].nextBranchID},'${branchName}','${branchLocation}');`,
            (err, result) => {
              res.send(result);
            }
          );
        }
      );
      break;
    case "delete":
      pool.query(
        `DELETE FROM branch WHERE branchNum=${branchNum}`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    case "update":
      pool.query(
        `UPDATE branch SET branchName = ${branchName}, branchLocation = ${branchLocation} WHERE branchNum = ${branchNum};`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    default:
      pool.query(`SELECT * FROM branch`, (err, result) => {
        res.send(result);
      });
  }
});

module.exports = router;

var express = require("express");
var pool = require("../DB/mysqldb");
var router = express.Router();


router.get("/", (req, res, next) => {
    let bookCode = req.query.bookCode;
    let authorNum = req.query.authorNum;
    let sequence = req.query.sequence;
    let query;

    if(bookCode){
      query = `SELECT * Wrote WHERE Wrote.bookCode = '${bookCode}';`;
    } else if(authorNum){
        query = `SELECT * Wrote WHERE Wrote.authorNum = '${authorNum}';`;
    } else if(sequence){
        query = `SELECT * Wrote WHERE Wrote.sequence = '${sequence}';`;
    }
    else {
      query = `SELECT * FROM Wrote;`;
    }
    
    pool.query(query, (err, result) => {
      res.send(result);
    });
  });

module.exports = router;

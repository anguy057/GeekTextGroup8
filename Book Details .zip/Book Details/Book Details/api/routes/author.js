var express = require("express");
var pool = require("../DB/mysqldb");
var router = express.Router();

router.get("/", (req, res) => {
  let authorNum = req.query.authorNum;
  let fName = req.query.authorFirst;
  let lName = req.query.authorLast;
  let query;

  if (fName) {
    query = `SELECT * FROM author WHERE author.authorFirst = '${fName}';`;
  } else if (lName) {
    query = `SELECT * FROM author WHERE author.authorLast = '${lName}';`;
  } else if (authorNum) {
    query = `SELECT * FROM author WHERE author.authorNum = '${authorNum}';`;
  } else {
    query = `SELECT * FROM author;`;
  }

  pool.query(query, (err, result) => {
    res.send(result);
  });
});

router.post("/", (req, res) => {
  let reqType = req.query.reqType || "";
  let authorNum = req.query.authorNum || "";
  let authorLast = req.query.authorLast || "";
  let authorFirst = req.query.authorFirst || "";

  switch (reqType) {
    case "add":
      pool.query(
        `SELECT COUNT(authorNum) + 1 AS nextAuthorID FROM Author`,
        (err, max) => {
          pool.query(
            `INSERT INTO author (authorNum,authorLast,authorFirst) VALUES (${max[0].nextAuthorID},'${authorLast}','${authorFirst}');`,
            (err, result) => {
              res.send(result);
            }
          );
        }
      );
      break;
    case "delete":
      pool.query(
        `DELETE FROM author WHERE authorFirst=${authorFirst} AND authorLast=${authorLast}`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    case "update":
      pool.query(
        `UPDATE author SET authorLast = '${authorLast}', authorFirst = '${authorFirst}' WHERE authorNum = ${authorNum};`,
        (err, result) => {
          res.send(result);
        }
      );
      break;
    default:
      pool.query(`SELECT * FROM author`, (err, result) => {
        res.send(result);
      });
  }
});

module.exports = router;

import React from "react";
import { useHistory } from "react-router-dom";
import { Container, Table, Loader } from "semantic-ui-react";
import "./publisher.component.css";
export default function Publishers(props) {
  const { searchTerm, loading, tables, handlePublisherUpdate, handlePublisherDelete } = props;

  if (loading) {
    return (
      <Container>
        <Loader size="massive">Loading Books...</Loader>
      </Container>
    );
  }

  if (Array.isArray(tables)) {
    const filteredCollection = tables.filter((collection) => {
        return (
            collection.publisherCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
            collection.publisherName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            collection.city.toLowerCase().includes(searchTerm.toLowerCase())
        )}
      
    );
    return (
      <div className="m">
        <Table inverted compact  padded className="centered">
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell rowSpan="1">Publisher Code</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Publisher Name</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">City</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Edit</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Delete</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {filteredCollection.map((publisher, idx) => {
              return (
                <Table.Row key={idx}>
                  <Table.Cell>{publisher.publisherCode}</Table.Cell>
                  <Table.Cell>{publisher.publisherName}</Table.Cell>
                  <Table.Cell>{publisher.city}</Table.Cell>
                  <Table.Cell><a className="edit" onClick={() => handlePublisherUpdate(publisher)}>Edit</a></Table.Cell>
                  <Table.Cell><a className="delete" onClick={() => handlePublisherDelete(publisher)}>Delete</a></Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
      </div>
    );
  } else {
      return null
  }
}

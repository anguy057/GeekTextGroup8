export default function fixData(dataArray) {
  let fixedData = [];
  let freeze = 0;

  dataArray.forEach((book) => {
    if (!fixedData[freeze]) {
      fixedData.push({
        bookCode: book.bookCode,
        title: book.title,
        publisherCode: book.publisherCode,
        type: book.type,
        paperback: book.paperback,
        url: book.url,
        authorNum: [],
        authorName: [],
        branchNum: [],
        branchName: [],
        branchLocation: [],
        price: [],
        quality: [],
        copyNum: [],
      });
    }

    if (fixedData[freeze].title === book.title) {
      if (!fixedData[freeze].authorNum.includes(book.authorNum)) {
        fixedData[freeze].authorNum.push(book.authorNum);
      }

      if (!fixedData[freeze].authorName.includes(`${book.authorFirst}, ${book.authorLast} `)) {
        fixedData[freeze].authorName.push(
          `${book.authorFirst}, ${book.authorLast} `
        );
      }

      if (!fixedData[freeze].branchNum.includes(book.branchNum)) {
        fixedData[freeze].branchNum.push(book.branchNum);
      }

      if (!fixedData[freeze].branchName.includes(book.branchName)) {
        fixedData[freeze].branchName.push(book.branchName);
      }

      if (!fixedData[freeze].branchLocation.includes(book.branchLocation)) {
        fixedData[freeze].branchLocation.push(book.branchLocation);
      }

      fixedData[freeze].copyNum.push(book.copyNum);

      fixedData[freeze].price.push(book.price);

      fixedData[freeze].quality.push(book.quality);
    } else {
      freeze++;
    }
  });
  return fixedData;
}

import React from "react";
import { useHistory } from "react-router-dom";
import DataFix from "./fix.data";
import { Container, Table, Loader } from "semantic-ui-react";
import "./store.component.css";
export default function Books(props) {
  const { searchTerm, loading, collection } = props;

  if (loading) {
    return (
      <Container>
        <Loader size="massive">Loading Books...</Loader>
      </Container>
    );
  }

  if (Array.isArray(collection)) {
    const fixedCollection = DataFix(collection);
    const filteredCollection = fixedCollection.filter((collection) =>
      collection.title.toLowerCase().includes(searchTerm.toLowerCase())
    );
    return (
      <div className="m">
        <Table inverted compact  padded className="centered">
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell rowSpan="1">Book Code</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Book Title</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Publisher Code</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Type</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Paper Back</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Author</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Branch ID</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Branch</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Location</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Copy</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Price</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Qaulity</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {filteredCollection.map((book, idx) => {
              return (
                <Table.Row key={idx}>
                  <Table.Cell>{book.bookCode}</Table.Cell>
                  <Table.Cell>{book.title}</Table.Cell>
                  <Table.Cell>{book.publisherCode}</Table.Cell>
                  <Table.Cell>{book.type}</Table.Cell>
                  <Table.Cell>{book.paperback}</Table.Cell>
                  <Table.Cell>
                    {book.authorName.map((item) => {
                      return (
                        <React.Fragment>
                          <Table.Row textAlign='center'>
                            <Table.Cell>{item}</Table.Cell>
                          </Table.Row>
                        </React.Fragment>
                      );
                    })}
                  </Table.Cell>
                  <Table.Cell>
                    {book.branchNum.map((item) => {
                      return (
                        <React.Fragment>
                          <Table.Row textAlign='center'>
                            <Table.Cell>{item}</Table.Cell>
                          </Table.Row>
                        </React.Fragment>
                      );
                    })}
                  </Table.Cell>
                  <Table.Cell>
                    {book.branchName.map((item) => {
                      return (
                        <React.Fragment>
                          <Table.Row textAlign='center'>
                            <Table.Cell>{item}</Table.Cell>
                          </Table.Row>
                        </React.Fragment>
                      );
                    })}
                  </Table.Cell>
                  <Table.Cell>
                    {book.branchLocation.map((item) => {
                      return (
                        <React.Fragment>
                          <Table.Row textAlign='center'>
                            <Table.Cell>{item}</Table.Cell>
                          </Table.Row>
                        </React.Fragment>
                      );
                    })}
                  </Table.Cell>
                  <Table.Cell>
                    {book.copyNum.map((item) => {
                      return (
                        <React.Fragment>
                          <Table.Row textAlign='center'>
                            <Table.Cell>{item}</Table.Cell>
                          </Table.Row>
                        </React.Fragment>
                      );
                    })}
                  </Table.Cell>
                  <Table.Cell>
                    {book.price.map((item) => {
                      return (
                        <React.Fragment>
                          <Table.Row textAlign='center'>
                            <Table.Cell>{item}</Table.Cell>
                          </Table.Row>
                        </React.Fragment>
                      );
                    })}
                  </Table.Cell>
                  <Table.Cell>
                    {book.quality.map((item) => {
                      return (
                        <React.Fragment> 
                          <Table.Row textAlign='center'>
                            <Table.Cell>{item}</Table.Cell>
                          </Table.Row>
                        </React.Fragment>
                      );
                    })}
                  </Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
      </div>
    );
  }
}

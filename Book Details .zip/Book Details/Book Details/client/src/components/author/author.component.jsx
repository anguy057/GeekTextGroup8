import React from "react";
import { useHistory } from "react-router-dom";
import { Container, Table, Loader } from "semantic-ui-react";
import "./author.component.css";
export default function Authors(props) {
  const { searchTerm, loading, tables,  handleAuthorDelete, handleAuthorUpdate } = props;

  if (loading) {
    return (
      <Container>
        <Loader size="massive">Loading...</Loader>
      </Container>
    );
  }

  if (Array.isArray(tables)) {
    const filteredCollection = tables.filter((collection) => {
      return (
        collection.authorNum.toString() === searchTerm ||
        collection.authorLast
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        collection.authorFirst.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
    return (
      <div className="m">
        <Table inverted compact padded className="centered">
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell rowSpan="1">Author ID</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Last Name</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">First Name</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Edit</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Delete</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {filteredCollection.map((author, idx) => {
              return (
                <Table.Row key={idx}>
                  <Table.Cell>{author.authorNum}</Table.Cell>
                  <Table.Cell>{author.authorLast}</Table.Cell>
                  <Table.Cell>{author.authorFirst}</Table.Cell>
                  <Table.Cell>
                    <a
                      className="edit"
                      onClick={() => handleAuthorUpdate(author)}
                    >
                      Edit
                    </a>
                  </Table.Cell>
                  <Table.Cell>
                    <a
                      className="delete"
                      onClick={() => handleAuthorDelete(author)}
                    >
                      Delete
                    </a>
                  </Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
      </div>
    );
  } else {
    return null;
  }
}

import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import { Menu, Input, Dropdown } from "semantic-ui-react";

export default function Header(props) {
  const { navTitle, placeHolder,handleSearch } = props;
  const dropDownItemTables = [
    "Store",
    "Authors",
    "Books",
    "Publishers",
    "Branches",
    "Copies",
    "Inventory",
  ];
  const dropDownItemAdd = [
    "Add-Author",
    "Add-Book",
    "Add-Publisher",
    "Add-Branch",
    "Add-Copy",
    "Add-Inventory",
  ];
  const [dropDownStateTables, setDropDownStateTables] = useState("Tables");
  const [dropDownStateAdd, setDropDownStateAdd] = useState("Add Item");

  let history = useHistory();

  const handleTableSelect = (name) => {
    setDropDownStateTables(name);
    switch (name) {
      case "Authors":
        history.push(`/${name}`);
        break;
      case "Books":
        history.push(`/${name}`);
        break;
      case "Publishers":
        history.push(`/${name}`);
        break;
      case "Branches":
        history.push(`/${name}`);
        break;
      case "Copies":
        history.push(`/${name}`);
        break;
      case "Inventory":
        history.push(`/${name}`);
        break;
      default:
        history.push(`/`);
        break;
    }
  };

  const handleAddSelect = (name) => {
    setDropDownStateAdd(name);
    switch (name) {
      case "Add-Author":
        history.push(`/${name}`);
        break;
      case "Add-Book":
        history.push(`/${name}`);
        break;
      case "Add-Publisher":
        history.push(`/${name}`);
        break;
      case "Add-Branch":
        history.push(`/${name}`);
        break;
      case "Add-Copy":
        history.push(`/${name}`);
        break;
      case "Add-Inventory":
        history.push(`/${name}`);
        break;
      default:
        history.push(`/`);
        break;
    }
  };

  const handleHomeLink = (e) => {
    history.push(`/`);
  };

  return (
    <Menu inverted>
      <Menu.Item header name="Store" onClick={handleHomeLink}>
        {navTitle}
      </Menu.Item>
      <Menu.Menu position="right">
        <Menu.Item>
          <Input
            onChange={handleSearch}
            icon="search"
            placeholder={placeHolder}
          />
        </Menu.Item>
        <Dropdown item text={dropDownStateAdd}>
          <Dropdown.Menu>
            {dropDownItemAdd.map((item) => (
              <Dropdown.Item
                value={item}
                onClick={(e) => handleAddSelect(e.target.innerHTML)}
              >
                {item}
              </Dropdown.Item>
            ))}
          </Dropdown.Menu>
        </Dropdown>
        <Dropdown item text={dropDownStateTables}>
          <Dropdown.Menu>
            {dropDownItemTables.map((item) => (
              <Dropdown.Item
                value={item}
                onClick={(e) => handleTableSelect(e.target.innerHTML)}
              >
                {item}
              </Dropdown.Item>
            ))}
          </Dropdown.Menu>
        </Dropdown>
      </Menu.Menu>
    </Menu>
  );
}

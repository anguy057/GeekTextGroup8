import React from "react";
import { useHistory } from "react-router-dom";
import { Container, Table, Loader } from "semantic-ui-react";
import "./copy.component.css";
export default function Copies(props) {
  const { searchTerm, loading, tables, handleCopyUpdate, handleCopyDelete } = props;

  if (loading) {
    return (
      <Container>
        <Loader size="massive">Loading Books...</Loader>
      </Container>
    );
  }

  if (Array.isArray(tables)) {
    const filteredCollection = tables.filter((collection) => {
    return(
        collection.bookCode.toLowerCase().includes(searchTerm.toLowerCase())||
        collection.branchNum.toString() === searchTerm ||
        collection.copyNum.toString() === searchTerm ||
        collection.quality.toLowerCase().includes(searchTerm.toLowerCase())||
        collection.price.toString() === searchTerm

    )}
      
    );
    return (
      <div className="m">
        <Table inverted compact  padded className="centered">
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell rowSpan="1">Book Code</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Branch ID</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Copy Number</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Quality</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Price</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Edit</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Delete</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {filteredCollection.map((copy, idx) => {
              return (
                <Table.Row key={idx}>
                  <Table.Cell>{copy.bookCode}</Table.Cell>
                  <Table.Cell>{copy.branchNum}</Table.Cell>
                  <Table.Cell>{copy.copyNum}</Table.Cell>
                  <Table.Cell>{copy.quality}</Table.Cell>
                  <Table.Cell>{`$${copy.price}`}</Table.Cell>
                  <Table.Cell><a className="edit" onClick={() => handleCopyUpdate(copy)}>Edit</a></Table.Cell>
                  <Table.Cell><a className="delete" onClick={() => handleCopyDelete(copy)}>Delete</a></Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
      </div>
    );
  } else {
      return null
  }
}

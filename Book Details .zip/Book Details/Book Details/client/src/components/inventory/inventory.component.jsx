import React from "react";
import { useHistory } from "react-router-dom";
import { Container, Table, Loader } from "semantic-ui-react";
import "./inventory.component.css";
export default function Inventory(props) {
  const { searchTerm, loading, tables} = props;

  if (loading) {
    return (
      <Container>
        <Loader size="massive">Loading Books...</Loader>
      </Container>
    );
  }

  if (Array.isArray(tables)) {
    const filteredCollection = tables.filter((collection) => {
      return (
          collection.BookCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
          collection.BranchNum.toString() === (searchTerm) ||
          collection.OnHand.toString() === (searchTerm)
      )
    });
    return (
      <div className="m">
        <Table inverted compact className="centered">
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell rowSpan="1">Book Code</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Branch ID</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Available</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {filteredCollection.map((inventory, idx) => {
              return (
                <Table.Row key={idx}>
                  <Table.Cell className="hover">{inventory.BookCode}</Table.Cell>
                  <Table.Cell>{inventory.BranchNum}</Table.Cell>
                  <Table.Cell>{inventory.OnHand}</Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
      </div>
    );
  } else {
    return null;
  }
}

import React from "react";
import { useHistory } from "react-router-dom";
import { Container, Table, Loader } from "semantic-ui-react";
import "./branch.component.css";
export default function Branches(props) {
  const { searchTerm, loading, tables, handleBranchUpdate, handleBranchDelete } = props;

  if (loading) {
    return (
      <Container>
        <Loader size="massive">Loading Books...</Loader>
      </Container>
    );
  }

  if (Array.isArray(tables)) {
    const filteredCollection = tables.filter((collection) =>{
      return (collection.branchNum.toString() === searchTerm|| 
      collection.branchName.toLowerCase().includes(searchTerm.toLowerCase())||
      collection.branchLocation.toLowerCase().includes(searchTerm.toLowerCase()))
    }
    );
    return (
      <div className="m">
        <Table inverted compact  padded className="centered">
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell rowSpan="1">Branch ID</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Branch Name</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Branch Location</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Edit</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Delete</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {filteredCollection.map((branch, idx) => {
              return (
                <Table.Row key={idx}>
                  <Table.Cell>{branch.branchNum}</Table.Cell>
                  <Table.Cell>{branch.branchName}</Table.Cell>
                  <Table.Cell>{branch.branchLocation}</Table.Cell>
                  <Table.Cell><a className="edit" onClick={() => handleBranchUpdate(branch)}>Edit</a></Table.Cell>
                  <Table.Cell><a className="delete" onClick={() => handleBranchDelete(branch)}>Delete</a></Table.Cell>
                  </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
      </div>
    );
  }else {
      return null
  }
}

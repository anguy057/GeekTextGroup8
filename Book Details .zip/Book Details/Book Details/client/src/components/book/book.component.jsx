import React from "react";
import { useHistory } from "react-router-dom";
import { Container, Table, Loader } from "semantic-ui-react";
import "./book.component.css";
export default function Books(props) {
  const { searchTerm, loading, tables, handleBookUpdate, handleBookDelete } = props;

  if (loading) {
    return (
      <Container>
        <Loader size="massive">Loading...</Loader>
      </Container>
    );
  }
  if (Array.isArray(tables)) {
    const filteredCollection = tables.filter((collection) => {
      return (
        collection.bookCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        collection.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        collection.publisherCode
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        collection.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
        collection.paperback.includes(searchTerm)
      );
    });
    return (
      <div className="m">
        <Table inverted compact padded className="centered">
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell rowSpan="1">Book Code</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Book Title</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Publisher Code</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Type</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Paper Back</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Edit</Table.HeaderCell>
              <Table.HeaderCell rowSpan="1">Delete</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {filteredCollection.map((book, idx) => {
              return (
                <Table.Row key={idx}>
                  <Table.Cell>{book.bookCode}</Table.Cell>
                  <Table.Cell>{book.title}</Table.Cell>
                  <Table.Cell>{book.publisherCode}</Table.Cell>
                  <Table.Cell>{book.type}</Table.Cell>
                  <Table.Cell>{book.paperback}</Table.Cell>
                  <Table.Cell><a className="edit" onClick={() => handleBookUpdate(book)}>Edit</a></Table.Cell>
                  <Table.Cell><a className="delete" onClick={() => handleBookDelete(book)}>Delete</a></Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
      </div>
    );
  } else {
    return null;
  }
}

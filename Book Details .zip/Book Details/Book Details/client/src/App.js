import React, { useState, useEffect } from "react";
import { Switch, Route, useHistory } from "react-router-dom";
import axios from "axios";

import Navigation from "./components/nav/nav.component";
import Store from "./components/store/store.component";
import Books from "./components/book/book.component";
import Authors from "./components/author/author.component";
import Publishers from "./components/publisher/publisher.component";
import Branches from "./components/branch/branch.component";
import Copies from "./components/copy/copy.component";
import Inventory from "./components/inventory/inventory.component";
import Add_Book from "./forms/book/form.book.component";
import Add_Author from "./forms/author/form.author.component";
import Add_Publisher from "./forms/publisher/form.publisher.component";
import Add_Branch from "./forms/branch/form.branch.component";
import Add_Copy from "./forms/copy/form.copy.component";
import Add_Inventory from "./forms/inventory/form.inventory.component";
import Delete_Book from "./forms/book/form.delete.book.component";
import Delete_Author from "./forms/author/form.delete.author.component";
import Delete_Publisher from "./forms/publisher/form.delete.publisher.component";
import Delete_Branch from "./forms/branch/form.delete.branch.component";
import Delete_Copy from "./forms/copy/form.delete.copy.component";
import "./App.css";
import "semantic-ui-css/semantic.min.css";

export const App = (props) => {
  // History
  let history = useHistory();
  // Navigation State
  const [navTitle] = useState("Henry's Book Emporium");
  const [placeHolder] = useState("Search for...");
  const [searchTerm, setSearchTerm] = useState("");
  // Book Data
  const [loading, setLoading] = useState(false);
  const [collection, setCollection] = useState([]);
  const [tables, setTables] = useState({});
  // Updates to DB
  const [updatesToDB, setUpdatesToDB] = useState(false);
  // Methods

  const handleSearch = (event) => {
    event.preventDefault();
    setSearchTerm(event.target.value);
  };

  const handleUpdates = (response) => {
    setUpdatesToDB(response);
  };

  const fetchCollection = async () => {
    setLoading(true);
    await axios.get(`https://henry-books-database.herokuapp.com/insert`);
    const store = await axios.get(
      `https://henry-books-database.herokuapp.com/store`
    );
    const books = await axios.get(
      "https://henry-books-database.herokuapp.com/book"
    );
    const authors = await axios.get(
      "https://henry-books-database.herokuapp.com/author"
    );
    const branches = await axios.get(
      "https://henry-books-database.herokuapp.com/branch"
    );
    const copies = await axios.get(
      "https://henry-books-database.herokuapp.com/copy"
    );
    const inventory = await axios.get(
      "https://henry-books-database.herokuapp.com/inventory"
    );
    const publishers = await axios.get(
      "https://henry-books-database.herokuapp.com/publisher"
    );

    const tables = {
      book: books.data,
      author: authors.data,
      branch: branches.data,
      copy: copies.data,
      inventory: inventory.data,
      publisher: publishers.data,
    };

    setTables(tables);
    setCollection(store.data);
    setLoading(false);
  };

  const [authorData, setauthorData] = useState({});
  const [bookData, setbookData] = useState({});
  const [publisherData, setpublisherData] = useState({});
  const [branchData, setbranchData] = useState({});
  const [copyData, setcopyData] = useState({});

  const handleAuthorUpdate = (Author) => {
    setauthorData(Author);
    history.push('Update-Author');
  };
  const handleAuthorDelete = (Author) => {
    setauthorData(Author);
    history.push('Delete-Author');
  };

  const handleBookUpdate = (Book) => {
    setbookData(Book);
    history.push('Update-Book');
  };
  const handleBookDelete = (Book) => {
    setbookData(Book);
    history.push('Delete-Book');
  };

  const handlePublisherUpdate = (Publisher) => {
    setpublisherData(Publisher);
    history.push('Update-Publisher');
  };
  const handlePublisherDelete = (Publisher) => {
    setpublisherData(Publisher);
    history.push('Delete-Publisher');
  };

  const handleBranchUpdate = (Branch) => {
    setbranchData(Branch);
    history.push('Update-Branch');
  };
  const handleBranchDelete = (Branch) => {
    setbranchData(Branch);
    history.push('Delete-Branch');
  };

  const handleCopyUpdate = (Copy) => {
    setcopyData(Copy);
    history.push('Update-Copy');
  };
  const handleCopyDelete = (Copy) => {
    setcopyData(Copy);
    history.push('Delete-Copy');
  };

  // Life Cycle
  useEffect(() => {
    fetchCollection();
  }, [updatesToDB]);

  return (
    <div>
      <Navigation
        {...props}
        navTitle={navTitle}
        placeHolder={placeHolder}
        handleSearch={handleSearch}
      />
      <Switch>
        <Route
          exact
          path="/"
          component={(props) => (
            <Store
              {...props}
              searchTerm={searchTerm}
              loading={loading}
              collection={collection}
            />
          )}
        />
        <Route
          exact
          path="/Books"
          component={(props) => (
            <Books
              {...props}
              searchTerm={searchTerm}
              loading={loading}
              tables={tables.book}
              handleBookUpdate={handleBookUpdate}
              handleBookDelete={handleBookDelete}
            />
          )}
        />
        <Route
          exact
          path="/Authors"
          component={(props) => (
            <Authors
              {...props}
              searchTerm={searchTerm}
              loading={loading}
              tables={tables.author}
              handleAuthorUpdate={handleAuthorUpdate}
              handleAuthorDelete={handleAuthorDelete}
            />
          )}
        />
        <Route
          exact
          path="/Publishers"
          component={(props) => (
            <Publishers
              {...props}
              searchTerm={searchTerm}
              loading={loading}
              tables={tables.publisher}
              handlePublisherUpdate={handlePublisherUpdate}
              handlePublisherDelete={handlePublisherDelete}
            />
          )}
        />
        <Route
          exact
          path="/Branches"
          component={(props) => (
            <Branches
              {...props}
              searchTerm={searchTerm}
              loading={loading}
              tables={tables.branch}
              handleBranchUpdate={handleBranchUpdate}
              handleBranchDelete={handleBranchDelete}
            />
          )}
        />
        <Route
          exact
          path="/Copies"
          component={(props) => (
            <Copies
              {...props}
              searchTerm={searchTerm}
              loading={loading}
              tables={tables.copy}
              handleCopyUpdate={handleCopyUpdate}
              handleCopyDelete={handleCopyDelete}
            />
          )}
        />
        <Route
          exact
          path="/Inventory"
          component={(props) => (
            <Inventory
              {...props}
              searchTerm={searchTerm}
              loading={loading}
              tables={tables.inventory}
            />
          )}
        />
        <Route
          exact
          path="/Add-Book"
          component={(props) => (
            <Add_Book
              {...props}
              handleUpdates={handleUpdates}
              tables={tables.book}
            />
          )}
        />
        <Route
          exact
          path="/Add-Author"
          component={(props) => (
            <Add_Author
              {...props}
              tables={tables.author}
              handleUpdates={handleUpdates}
            />
          )}
        />
        <Route
          exact
          path="/Add-Publisher"
          component={(props) => (
            <Add_Publisher
              {...props}
              handleUpdates={handleUpdates}
              tables={tables.publisher}
            />
          )}
        />
        <Route
          exact
          path="/Add-Branch"
          component={(props) => (
            <Add_Branch
              {...props}
              handleUpdates={handleUpdates}
              tables={tables.branch}
            />
          )}
        />
        <Route
          exact
          path="/Add-Copy"
          component={(props) => (
            <Add_Copy
              {...props}
              handleUpdates={handleUpdates}
              tables={tables.copy}
            />
          )}
        />
        <Route
          exact
          path="/Add-Inventory"
          component={(props) => (
            <Add_Inventory
              {...props}
              handleUpdates={handleUpdates}
              tables={tables.inventory}
            />
          )}
        />
        <Route
          exact
          path="/Delete-Book"
          component={(props) => (
            <Delete_Book
              {...props}
              handleUpdates={handleUpdates}
              tables={tables.book}
              bookData={bookData}
            />
          )}
        />
        <Route
          exact
          path="/Delete-Author"
          component={(props) => (
            <Delete_Author
              {...props}
              tables={tables.author}
              handleUpdates={handleUpdates}
              authorData={authorData}
            />
          )}
        />
        <Route
          exact
          path="/Delete-Publisher"
          component={(props) => (
            <Delete_Publisher
              {...props}
              handleUpdates={handleUpdates}
              tables={tables.publisher}
              publisherData={publisherData}
            />
          )}
        />
        <Route
          exact
          path="/Delete-Branch"
          component={(props) => (
            <Delete_Branch
              {...props}
              handleUpdates={handleUpdates}
              tables={tables.branch}
              branchData={branchData}
            />
          )}
        />
        <Route
          exact
          path="/Delete-Copy"
          component={(props) => (
            <Delete_Copy
              {...props}
              handleUpdates={handleUpdates}
              tables={tables.copy}
              copyData={copyData}
            />
          )}
        />
      </Switch>
    </div>
  );
};

export default App;

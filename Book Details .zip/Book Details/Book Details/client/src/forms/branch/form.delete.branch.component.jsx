import React, {useState} from 'react'
import {useHistory} from 'react-router-dom';
import axios from 'axios';
import { Button, Form, Segment } from 'semantic-ui-react'


export default function AddAuthor ({handleUpdates, branchData}){
let history = useHistory();

const deleteBranch = async () => {
  await axios.post(`https://henry-books-database.herokuapp.com/branch?branchNum=${branchData.branchNum}&reqType=delete`);
  handleUpdates(true);
  history.push('/Branches')
};
  return(
    <Segment inverted>
      <Form inverted>
        <Form.Group widths='equal'>
          <Form.Input fluid disabled label='Branch Name' value={branchData.branchName}/>
          <Form.Input fluid disabled label='Branch Location' value={branchData.branchLocation}/>
        </Form.Group>
        <Button type='submit' onClick={deleteBranch}>Delete Branch</Button>
      </Form>
    </Segment>
  )
  
}

import React, {useState} from 'react'
import {useHistory} from 'react-router-dom';
import axios from 'axios';
import { Button, Form, Segment } from 'semantic-ui-react'


export default function AddAuthor ({handleUpdates}){
const [branchName, setBranchName] = useState("");
const [branchLocation, setBranchLocation] = useState("");
let history = useHistory();

const insertBranch = async () => {
  await axios.post(`https://henry-books-database.herokuapp.com/branch?branchName=${branchName}&branchLocation=${branchLocation}&reqType=add`);
  handleUpdates(true);
  history.push('/Branches')
};
  return(
    <Segment inverted>
      <Form inverted>
        <Form.Group widths='equal'>
          <Form.Input fluid label='Branch Name' placeholder='Branch Name' onChange={e => setBranchName(e.target.value)}/>
          <Form.Input fluid label='Branch Location' placeholder='Branch Location' onChange={e => setBranchLocation(e.target.value)}/>
        </Form.Group>
        <Button type='submit' onClick={insertBranch}>Add Branch</Button>
      </Form>
    </Segment>
  )
  
}

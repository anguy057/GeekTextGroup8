import React, {useState} from 'react'
import {useHistory} from 'react-router-dom';
import axios from 'axios';
import { Button, Form, Segment } from 'semantic-ui-react'


export default function AddAuthor ({handleUpdates}){
const [authorFirst, setAuthorFirst] = useState("");
const [authorLast, setAuthorLast] = useState("");
let history = useHistory();

const insertAuthor = async () => {
  await axios.post(`https://henry-books-database.herokuapp.com/author?authorLast=${authorLast}&authorFirst=${authorFirst}&reqType=add`);
  handleUpdates(true);
  history.push('/Authors')
};
  return(
    <Segment inverted>
      <Form inverted>
        <Form.Group widths='equal'>
          <Form.Input fluid label='Author Last' placeholder='Last name' onChange={e => setAuthorLast(e.target.value)}/>
          <Form.Input fluid label='Author First' placeholder='First name' onChange={e => setAuthorFirst(e.target.value)}/>
        </Form.Group>
        <Button type='submit' onClick={insertAuthor}>Add Author</Button>
      </Form>
    </Segment>
  )
  
}

import React, {useState} from 'react'
import {useHistory} from 'react-router-dom';
import axios from 'axios';
import { Button, Form, Segment } from 'semantic-ui-react'


export default function DeleteAuthor ({handleUpdates, authorData}){
let history = useHistory();

const deleteAuthor = async () => {
  await axios.post(`https://henry-books-database.herokuapp.com/author?authorLast=${authorData.authorLast}&authorFirst=${authorData.authorFirst}&reqType=add`);
  handleUpdates(true);
  history.push('/Authors')
};
  return(
    <Segment inverted>
      <Form inverted>
        <Form.Group widths='equal'>
        <Form.Input disabled fluid label='Author ID' value={authorData.authorNum} />
          <Form.Input disabled fluid label='Author Last' value={authorData.authorLast} />
          <Form.Input disabled fluid label='Author First' value={authorData.authorFirst}/>
        </Form.Group>
        <Button type='submit' onClick={deleteAuthor}>Delete Author</Button>
      </Form>
    </Segment>
  )
  
}

import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";
import { Button, Form, Segment } from "semantic-ui-react";

export default function AddBook({ handleUpdates, bookData}) {
  let history = useHistory();


  const deleteBook = async () => {
    await axios.post(
      `https://henry-books-database.herokuapp.com/book?bookCode=${bookData.bookCode}&reqType=delete`
    );
    handleUpdates(true);
    history.push("/Books");
  };
  return (
    <Segment inverted>
      <Form inverted>
        <Form.Group widths="equal">
          <Form.Input
            label="Book Code"
            disabled
            value={bookData.bookCode}
          />
          <Form.Input
            label="Book Title"
            disabled
            value={bookData.title}
          />
          <Form.Input
            label="Publisher Code"
            disabled
            value={bookData.publisherCode}
          />
        </Form.Group>

        <Form.Group>
          <Form.Input
            label="Type"
            disabled
            value={bookData.type}
          >
          </Form.Input>
          <Form.Input
            label="Paperback"
            disabled
            value={bookData.paperback}
          >

          </Form.Input>
        </Form.Group>

        <Button type="submit" onClick={deleteBook}>
          Delete Book
        </Button>
      </Form>
    </Segment>
  );
}

import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";
import { Button, Form, Segment } from "semantic-ui-react";

export default function AddBook({ handleUpdates }) {
  const [bookCode, setbookCode] = useState("");
  const [title, setTitle] = useState("");
  const [publisherCode, setPublisherCode] = useState("");
  const [type, setType] = useState("");
  const [paperback, setPaperback] = useState("");

  let history = useHistory();

  const handleChangeType = (event) => {
    setType(event.target.value);
  };

  const handleChangePaperBack = (event) => {
    setPaperback(event.target.value);
  };

  const insertBook = async () => {
    await axios.post(
      `https://henry-books-database.herokuapp.com/book?bookCode=${bookCode}&title=${title}&publisherCode=${publisherCode}&type=${type}&paperback=${paperback}&reqType=add`
    );
    handleUpdates(true);
    history.push("/Books");
  };
  return (
    <Segment inverted>
      <Form inverted>
        <Form.Group widths="equal">
          <Form.Input
            label="Book Code"
            placeholder="Book Code"
            onChange={(e) => setbookCode(e.target.value)}
          />
          <Form.Input
            label="Book Title"
            placeholder="Book Title"
            onChange={(e) => setTitle(e.target.value)}
          />
          <Form.Input
            label="Publisher Code"
            placeholder="Publisher Code"
            onChange={(e) => setPublisherCode(e.target.value)}
          />
        </Form.Group>

        <Form.Group>
          <Form.Field
            label="Type"
            control="select"
            placeholder="Type"
            onChange={(event) => handleChangePaperBack(event)}
          >
            <option disabled selected="true">
              Select
            </option>
            <option value="FIC">FIC</option>
            <option value="SFI">SFI</option>
            <option value="ART">ART</option>
            <option value="POE">POE</option>
            <option value="PSY">PSY</option>
            <option value="SCI">SCI</option>
            <option value="TRA">TRA</option>
            <option value="HIS">HIS</option>
            <option value="CMP">CMP</option>
            <option value="PHI">PHI</option>
            <option value="HOR">HOR</option>
            <option value="MYS">MYS</option>
          </Form.Field>
          <Form.Field
            label="Paperback"
            control="select"
            placeholder="Paperback"
            onChange={(event) => handleChangeType(event)}
          >
            <option disabled selected="true">
              Select
            </option>
            <option value="Y">Y</option>
            <option value="N">N</option>
          </Form.Field>
        </Form.Group>

        <Button type="submit" onClick={insertBook}>
          Add Book
        </Button>
      </Form>
    </Segment>
  );
}

import React, {useState} from 'react'
import {useHistory} from 'react-router-dom';
import axios from 'axios';
import { Button, Form, Segment } from 'semantic-ui-react'


export default function AddAuthor ({handleUpdates}){
const [bookCode, setBookCode] = useState("");
const [branchNum, setBranchNum] = useState("");
const [copyNum, setCopyNum] = useState("");
const [quality, setQaulity] = useState("");
const [price, setPrice] = useState("");
let history = useHistory();

const insertCopy = async () => {
  await axios.post(`https://henry-books-database.herokuapp.com/copy?bookCode=${bookCode}&branchNum=${branchNum}&copyNum=${copyNum}&quality=${quality}&price=${price}&reqType=add`);
  handleUpdates(true);
  history.push('/Copies')
};
  return(
    <Segment inverted>
      <Form inverted>
        <Form.Group widths='equal'>
          <Form.Input fluid label='Book Code' placeholder='Book Code' onChange={e => setBookCode(e.target.value)}/>
          <Form.Input fluid label='Branch ID' placeholder='Branch ID' onChange={e => setBranchNum(e.target.value)}/>
          <Form.Input fluid label='Copy Number' placeholder='Copy Number' onChange={e => setCopyNum(e.target.value)}/>
          <Form.Input fluid label='Quality' placeholder='Quality' onChange={e => setQaulity(e.target.value)}/>
          <Form.Input fluid label='Price' placeholder='Price' onChange={e => setPrice(e.target.value)}/>
        </Form.Group>
        <Button type='submit' onClick={insertCopy}>Add Copy</Button>
      </Form>
    </Segment>
  )
  
}

import React, {useState} from 'react'
import {useHistory} from 'react-router-dom';
import axios from 'axios';
import { Button, Form, Segment } from 'semantic-ui-react'


export default function AddAuthor ({handleUpdates, copyData}){
let history = useHistory();

const deleteCopy = async () => {
  await axios.post(`https://henry-books-database.herokuapp.com/copy?bookCode=${copyData.bookCode}&branchNum=${copyData.branchNum}&copyNum=${copyData.copyNum}&reqType=delete`);
  handleUpdates(true);
  history.push('/Copies')
};
  return(
    <Segment inverted>
      <Form inverted>
        <Form.Group widths='equal'>
          <Form.Input fluid label='Book Code' disabled values={copyData.bookCode}/>
          <Form.Input fluid label='Branch ID' disabled values={copyData.branchNum}/>
          <Form.Input fluid label='Copy Number' disabled values={copyData.copyNum}/>
          <Form.Input fluid label='Quality' disabled  values={copyData.quality}/>
          <Form.Input fluid label='Price' disabled values={copyData.price}/>
        </Form.Group>
        <Button type='submit' onClick={deleteCopy}>Delete Copy</Button>
      </Form>
    </Segment>
  )
  
}
